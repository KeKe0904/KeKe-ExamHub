﻿﻿﻿﻿﻿/**
 * KeKe ExamHub - 考试信息管理系统
 * @author 落梦陳 (KeKe0904) | B站/抖音: 落梦陳
 * @github https://github.com/KeKe0904/KeKe-ExamHub
 * 本项目使用 Trae IDE 开发
 * @license MIT
 */
import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  FileText,
  X,
  AlertTriangle,
  Loader2,
  Check,
  Settings,
  Calendar,
  Clock,
  MapPin,
  User,
} from "@/components/MathIcon";
import AdminLayout from "@/components/Layout/AdminLayout";
import StatusBadge from "@/components/StatusBadge";
import { useExamStore } from "@/store/examStore";
import {
  calculateExamStatus,
  formatDateTime,
  formatDuration,
} from "@/utils/date";
import type { Exam } from "@/types";

export default function ExamList() {
  const { exams, loading, fetchExams, deleteExam, batchDeleteExams, batchUpdateExams } = useExamStore();

  const [searchQuery, setSearchQuery] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<Exam | null>(null);
  const [deleting, setDeleting] = useState(false);

  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showBatchDelete, setShowBatchDelete] = useState(false);
  const [showBatchEdit, setShowBatchEdit] = useState(false);
  const [batchActionLoading, setBatchActionLoading] = useState(false);

  const [batchUpdates, setBatchUpdates] = useState<{
    examDate: boolean;
    duration: boolean;
    location: boolean;
    invigilator: boolean;
  }>({
    examDate: false,
    duration: false,
    location: false,
    invigilator: false,
  });

  const [batchValues, setBatchValues] = useState<{
    examDate: string;
    duration: string;
    location: string;
    invigilator: string;
  }>({
    examDate: "",
    duration: "",
    location: "",
    invigilator: "",
  });

  // 初始加载
  useEffect(() => {
    fetchExams();
  }, [fetchExams]);

  const filteredExams = useMemo(() => {
    return exams
      .map((exam) => ({ ...exam, status: calculateExamStatus(exam) }))
      .filter((exam) => {
        if (!searchQuery) return true;
        const query = searchQuery.toLowerCase();
        return (
          exam.subject.toLowerCase().includes(query) ||
          exam.location.toLowerCase().includes(query) ||
          exam.invigilator.toLowerCase().includes(query)
        );
      })
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }, [exams, searchQuery]);

  const allSelected = filteredExams.length > 0 && filteredExams.every((exam) => selectedIds.has(exam.id));
  const someSelected = selectedIds.size > 0 && !allSelected;

  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleToggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredExams.map((e) => e.id)));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteExam(deleteTarget.id);
      setDeleteTarget(null);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(deleteTarget.id);
        return next;
      });
    } catch (error) {
      console.error("删除失败:", error);
    } finally {
      setDeleting(false);
    }
  };

  const handleBatchDelete = async () => {
    if (selectedIds.size === 0) return;
    setBatchActionLoading(true);
    try {
      await batchDeleteExams(Array.from(selectedIds));
      setShowBatchDelete(false);
      setSelectedIds(new Set());
    } catch (error) {
      console.error("批量删除失败:", error);
    } finally {
      setBatchActionLoading(false);
    }
  };

  const handleBatchUpdate = async () => {
    if (selectedIds.size === 0) return;

    const updates: {
      examDate?: string;
      duration?: number;
      location?: string;
      invigilator?: string;
    } = {};

    if (batchUpdates.examDate && batchValues.examDate) {
      updates.examDate = new Date(batchValues.examDate).toISOString();
    }
    if (batchUpdates.duration && batchValues.duration) {
      updates.duration = parseInt(batchValues.duration, 10);
    }
    if (batchUpdates.location && batchValues.location) {
      updates.location = batchValues.location;
    }
    if (batchUpdates.invigilator && batchValues.invigilator) {
      updates.invigilator = batchValues.invigilator;
    }

    if (Object.keys(updates).length === 0) return;

    setBatchActionLoading(true);
    try {
      await batchUpdateExams(Array.from(selectedIds), updates);
      setShowBatchEdit(false);
      resetBatchForm();
    } catch (error) {
      console.error("批量修改失败:", error);
    } finally {
      setBatchActionLoading(false);
    }
  };

  const resetBatchForm = () => {
    setBatchUpdates({
      examDate: false,
      duration: false,
      location: false,
      invigilator: false,
    });
    setBatchValues({
      examDate: "",
      duration: "",
      location: "",
      invigilator: "",
    });
  };

  return (
    <AdminLayout>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="font-serif text-xl sm:text-2xl font-bold text-black dark:text-white mb-1">
            考试管理
          </h1>
          <p className="text-sm text-zinc-500 dark:text-zinc-300">
            {loading ? "加载中..." : `共 ${exams.length} 场考试`}
          </p>
        </div>
        <Link
          to="/admin/exams/new"
          className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-black dark:bg-white text-white dark:text-black text-sm font-medium rounded-lg hover:bg-zinc-800 dark:hover:bg-zinc-200 transition-colors w-full sm:w-auto"
        >
          <Plus className="w-4 h-4" />
          发布考试
        </Link>
      </div>

      <div className="bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-600 p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400 dark:text-zinc-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索考试科目、地点、监考老师..."
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-600 rounded-lg text-sm text-zinc-700 dark:text-zinc-300 placeholder:text-zinc-400 dark:placeholder:text-zinc-500 focus:outline-none focus:border-black dark:focus:border-white transition-all"
          />
        </div>
      </div>

      {selectedIds.size > 0 && (
        <div className="bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-600 p-4 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium text-black dark:text-white">
                已选择 <span className="text-zinc-600 dark:text-zinc-300">{selectedIds.size}</span> 项
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setSelectedIds(new Set())}
                className="px-3 py-1.5 text-sm font-medium text-zinc-600 dark:text-zinc-300 hover:text-black dark:hover:text-white border border-zinc-200 dark:border-zinc-600 rounded-lg hover:border-zinc-300 dark:hover:border-zinc-500 transition-colors"
              >
                取消选择
              </button>
              <button
                onClick={() => setShowBatchEdit(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-black dark:text-white border border-zinc-300 dark:border-zinc-600 rounded-lg hover:bg-zinc-50 dark:hover:bg-zinc-950 transition-colors"
              >
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">批量修改</span>
                <span className="sm:hidden">修改</span>
              </button>
              <button
                onClick={() => setShowBatchDelete(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-red-600 dark:text-red-400 border border-red-300 dark:border-red-700 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">批量删除</span>
                <span className="sm:hidden">删除</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-600 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 text-black dark:text-white animate-spin" />
            <span className="ml-2 text-zinc-500 dark:text-zinc-300">加载考试数据...</span>
          </div>
        ) : filteredExams.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-zinc-50 dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-600">
                  <th className="px-4 py-3 w-12">
                    <input
                      type="checkbox"
                      checked={allSelected}
                      ref={(el) => {
                        if (el) el.indeterminate = someSelected;
                      }}
                      onChange={handleToggleSelectAll}
                      className="w-4 h-4 rounded border-zinc-300 dark:border-zinc-600 text-black dark:text-white focus:ring-black dark:focus:ring-white cursor-pointer"
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-zinc-600 dark:text-zinc-300 uppercase tracking-wider">
                    考试科目
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-zinc-600 dark:text-zinc-300 uppercase tracking-wider">
                    考试时间
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-zinc-600 dark:text-zinc-300 uppercase tracking-wider">
                    时长
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-zinc-600 dark:text-zinc-300 uppercase tracking-wider">
                    地点
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-zinc-600 dark:text-zinc-300 uppercase tracking-wider">
                    状态
                  </th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-zinc-600 dark:text-zinc-300 uppercase tracking-wider">
                    操作
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-700">
                {filteredExams.map((exam) => (
                  <tr
                    key={exam.id}
                    className={`hover:bg-zinc-50 dark:hover:bg-zinc-950 transition-colors ${
                      selectedIds.has(exam.id) ? "bg-zinc-50 dark:bg-zinc-950" : ""
                    }`}
                  >
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(exam.id)}
                        onChange={() => handleToggleSelect(exam.id)}
                        className="w-4 h-4 rounded border-zinc-300 dark:border-zinc-600 text-black dark:text-white focus:ring-black dark:focus:ring-white cursor-pointer"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-zinc-100 dark:bg-zinc-900 flex items-center justify-center flex-shrink-0">
                          <FileText className="w-4 h-4 text-black dark:text-white" />
                        </div>
                        <div>
                          <div className="font-medium text-zinc-800 dark:text-zinc-200">
                            {exam.subject}
                          </div>
                          <div className="text-xs text-zinc-400 dark:text-zinc-400">
                            {exam.invigilator}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-zinc-600 dark:text-zinc-300">
                      {formatDateTime(exam.examDate)}
                    </td>
                    <td className="px-4 py-3 text-sm text-zinc-600 dark:text-zinc-300">
                      {formatDuration(exam.duration)}
                    </td>
                    <td className="px-4 py-3 text-sm text-zinc-600 dark:text-zinc-300">
                      {exam.location}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={exam.status} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <Link
                          to={`/admin/exams/${exam.id}/edit`}
                          className="p-2 text-black dark:text-white hover:text-zinc-600 dark:hover:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-950 rounded-lg transition-colors"
                          title="编辑"
                        >
                          <Edit className="w-4 h-4" />
                        </Link>
                        <button
                          onClick={() => setDeleteTarget(exam)}
                          className="p-2 text-red-500 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-950 rounded-lg transition-colors"
                          title="删除"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-16">
            <FileText className="w-12 h-12 mx-auto mb-3 text-zinc-300 dark:text-zinc-600" />
            <h3 className="text-lg font-medium text-zinc-600 dark:text-zinc-300 mb-1">
              {searchQuery ? "未找到匹配的考试" : "暂无考试信息"}
            </h3>
            <p className="text-sm text-zinc-400 dark:text-zinc-400 mb-4">
              {searchQuery ? "试试调整搜索条件" : "点击上方按钮发布第一场考试"}
            </p>
          </div>
        )}
      </div>

      {deleteTarget && (
        <DeleteConfirmDialog
          exam={deleteTarget}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          deleting={deleting}
        />
      )}

      {showBatchDelete && (
        <BatchDeleteDialog
          count={selectedIds.size}
          onConfirm={handleBatchDelete}
          onCancel={() => setShowBatchDelete(false)}
          loading={batchActionLoading}
        />
      )}

      {showBatchEdit && (
        <BatchEditDialog
          count={selectedIds.size}
          updates={batchUpdates}
          values={batchValues}
          onToggleField={(field) => {
            setBatchUpdates((prev) => ({ ...prev, [field]: !prev[field as keyof typeof prev] }));
          }}
          onValueChange={(field, value) => {
            setBatchValues((prev) => ({ ...prev, [field]: value }));
          }}
          onConfirm={handleBatchUpdate}
          onCancel={() => {
            setShowBatchEdit(false);
            resetBatchForm();
          }}
          loading={batchActionLoading}
        />
      )}
    </AdminLayout>
  );
}

interface DeleteConfirmDialogProps {
  exam: Exam;
  onConfirm: () => void;
  onCancel: () => void;
  deleting: boolean;
}

function DeleteConfirmDialog({
  exam,
  onConfirm,
  onCancel,
  deleting,
}: DeleteConfirmDialogProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 dark:bg-zinc-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-zinc-900 rounded-lg shadow-lg border border-zinc-200 dark:border-zinc-600 max-w-md w-full p-6 animate-scale-in">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 rounded-full bg-red-50 dark:bg-red-950 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-500 dark:text-red-400" />
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold text-black dark:text-white mb-1">
              确认删除
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-300">
              确定要删除考试「{exam.subject}」吗?此操作无法撤销。
            </p>
          </div>
        </div>
        <div className="flex justify-end gap-3">
          <button
            onClick={onCancel}
            disabled={deleting}
            className="px-4 py-2 text-sm font-medium text-black dark:text-white bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-600 hover:border-black dark:hover:border-white rounded-lg transition-colors disabled:opacity-50"
          >
            取消
          </button>
          <button
            onClick={onConfirm}
            disabled={deleting}
            className="px-4 py-2 text-sm font-medium text-red-600 dark:text-red-400 bg-white dark:bg-zinc-900 border border-red-300 dark:border-red-700 hover:bg-red-50 dark:hover:bg-red-950 rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {deleting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                删除中...
              </>
            ) : (
              "确认删除"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

interface BatchDeleteDialogProps {
  count: number;
  onConfirm: () => void;
  onCancel: () => void;
  loading: boolean;
}

function BatchDeleteDialog({
  count,
  onConfirm,
  onCancel,
  loading,
}: BatchDeleteDialogProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 dark:bg-zinc-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-zinc-900 rounded-lg shadow-lg border border-zinc-200 dark:border-zinc-600 max-w-md w-full p-6 animate-scale-in">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 rounded-full bg-red-50 dark:bg-red-950 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-500 dark:text-red-400" />
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold text-black dark:text-white mb-1">
              确认批量删除
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-300">
              确定要删除选中的 <span className="font-medium text-black dark:text-white">{count}</span> 场考试吗？此操作无法撤销。
            </p>
          </div>
        </div>
        <div className="flex justify-end gap-3">
          <button
            onClick={onCancel}
            disabled={loading}
            className="px-4 py-2 text-sm font-medium text-black dark:text-white bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-600 hover:border-black dark:hover:border-white rounded-lg transition-colors disabled:opacity-50"
          >
            取消
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className="px-4 py-2 text-sm font-medium text-red-600 dark:text-red-400 bg-white dark:bg-zinc-900 border border-red-300 dark:border-red-700 hover:bg-red-50 dark:hover:bg-red-950 rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                删除中...
              </>
            ) : (
              "确认删除"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

interface BatchEditDialogProps {
  count: number;
  updates: {
    examDate: boolean;
    duration: boolean;
    location: boolean;
    invigilator: boolean;
  };
  values: {
    examDate: string;
    duration: string;
    location: string;
    invigilator: string;
  };
  onToggleField: (field: string) => void;
  onValueChange: (field: string, value: string) => void;
  onConfirm: () => void;
  onCancel: () => void;
  loading: boolean;
}

function BatchEditDialog({
  count,
  updates,
  values,
  onToggleField,
  onValueChange,
  onConfirm,
  onCancel,
  loading,
}: BatchEditDialogProps) {
  const hasAnyField = Object.values(updates).some(Boolean);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 dark:bg-zinc-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-zinc-900 rounded-lg shadow-lg border border-zinc-200 dark:border-zinc-600 max-w-lg w-full p-6 animate-scale-in">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-serif text-lg font-bold text-black dark:text-white">
            批量修改考试
          </h3>
          <button
            onClick={onCancel}
            className="p-1 text-zinc-400 hover:text-black dark:hover:text-white rounded-md hover:bg-zinc-100 dark:hover:bg-zinc-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-sm text-zinc-600 dark:text-zinc-300 mb-4">
          已选择 <span className="font-medium text-black dark:text-white">{count}</span> 场考试，勾选要修改的字段并填写新值：
        </p>

        <div className="space-y-3 mb-6">
          <div className="flex items-start gap-3 p-3 border border-zinc-200 dark:border-zinc-700 rounded-lg hover:border-zinc-300 dark:hover:border-zinc-600 transition-colors">
            <input
              type="checkbox"
              checked={updates.examDate}
              onChange={() => onToggleField("examDate")}
              className="mt-0.5 w-4 h-4 rounded border-zinc-300 dark:border-zinc-600 text-black dark:text-white focus:ring-black dark:focus:ring-white cursor-pointer"
            />
            <div className="flex-1">
              <label className="flex items-center gap-2 text-sm font-medium text-black dark:text-white mb-2 cursor-pointer">
                <Calendar className="w-4 h-4 text-zinc-500" />
                考试时间
              </label>
              <input
                type="datetime-local"
                value={values.examDate}
                onChange={(e) => onValueChange("examDate", e.target.value)}
                disabled={!updates.examDate}
                className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-600 rounded-lg text-sm text-zinc-700 dark:text-zinc-300 focus:outline-none focus:border-black dark:focus:border-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 border border-zinc-200 dark:border-zinc-700 rounded-lg hover:border-zinc-300 dark:hover:border-zinc-600 transition-colors">
            <input
              type="checkbox"
              checked={updates.duration}
              onChange={() => onToggleField("duration")}
              className="mt-0.5 w-4 h-4 rounded border-zinc-300 dark:border-zinc-600 text-black dark:text-white focus:ring-black dark:focus:ring-white cursor-pointer"
            />
            <div className="flex-1">
              <label className="flex items-center gap-2 text-sm font-medium text-black dark:text-white mb-2 cursor-pointer">
                <Clock className="w-4 h-4 text-zinc-500" />
                考试时长
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={values.duration}
                  onChange={(e) => onValueChange("duration", e.target.value)}
                  disabled={!updates.duration}
                  placeholder="请输入时长"
                  min="1"
                  className="flex-1 px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-600 rounded-lg text-sm text-zinc-700 dark:text-zinc-300 focus:outline-none focus:border-black dark:focus:border-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                />
                <span className="text-sm text-zinc-500 dark:text-zinc-400 w-8">分钟</span>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 border border-zinc-200 dark:border-zinc-700 rounded-lg hover:border-zinc-300 dark:hover:border-zinc-600 transition-colors">
            <input
              type="checkbox"
              checked={updates.location}
              onChange={() => onToggleField("location")}
              className="mt-0.5 w-4 h-4 rounded border-zinc-300 dark:border-zinc-600 text-black dark:text-white focus:ring-black dark:focus:ring-white cursor-pointer"
            />
            <div className="flex-1">
              <label className="flex items-center gap-2 text-sm font-medium text-black dark:text-white mb-2 cursor-pointer">
                <MapPin className="w-4 h-4 text-zinc-500" />
                考试地点
              </label>
              <input
                type="text"
                value={values.location}
                onChange={(e) => onValueChange("location", e.target.value)}
                disabled={!updates.location}
                placeholder="请输入新地点"
                className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-600 rounded-lg text-sm text-zinc-700 dark:text-zinc-300 focus:outline-none focus:border-black dark:focus:border-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 border border-zinc-200 dark:border-zinc-700 rounded-lg hover:border-zinc-300 dark:hover:border-zinc-600 transition-colors">
            <input
              type="checkbox"
              checked={updates.invigilator}
              onChange={() => onToggleField("invigilator")}
              className="mt-0.5 w-4 h-4 rounded border-zinc-300 dark:border-zinc-600 text-black dark:text-white focus:ring-black dark:focus:ring-white cursor-pointer"
            />
            <div className="flex-1">
              <label className="flex items-center gap-2 text-sm font-medium text-black dark:text-white mb-2 cursor-pointer">
                <User className="w-4 h-4 text-zinc-500" />
                监考老师
              </label>
              <input
                type="text"
                value={values.invigilator}
                onChange={(e) => onValueChange("invigilator", e.target.value)}
                disabled={!updates.invigilator}
                placeholder="请输入新监考老师"
                className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-600 rounded-lg text-sm text-zinc-700 dark:text-zinc-300 focus:outline-none focus:border-black dark:focus:border-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <button
            onClick={onCancel}
            disabled={loading}
            className="px-4 py-2 text-sm font-medium text-black dark:text-white bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-600 hover:border-black dark:hover:border-white rounded-lg transition-colors disabled:opacity-50"
          >
            取消
          </button>
          <button
            onClick={onConfirm}
            disabled={loading || !hasAnyField}
            className="px-4 py-2 text-sm font-medium text-white dark:text-black bg-black dark:bg-white border border-black dark:border-white hover:bg-zinc-800 dark:hover:bg-zinc-200 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                修改中...
              </>
            ) : (
              <>
                <Check className="w-4 h-4" />
                确认修改
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
